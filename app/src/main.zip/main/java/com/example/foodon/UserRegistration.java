package com.example.foodon;

import androidx.appcompat.app.AppCompatActivity;
import com.example.foodon.R;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;

public class UserRegistration extends AppCompatActivity {
    TextInputLayout Fname, Lname, Emailid, Password, confirmpass, Mobilenumber, Location, Area;
    Button getlocation, already_registered, register;
    String fname,lname,emailid,password,confpassword,mobile,longitude,latitude, area,location;
    MyDatabaseHelper DB;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_registration);

        Fname = (TextInputLayout)findViewById(R.id.Fname);
        Lname = (TextInputLayout)findViewById(R.id.Lname);
        Emailid =(TextInputLayout) findViewById(R.id.Emailid);
        Password = (TextInputLayout) findViewById(R.id.Password);
        confirmpass = (TextInputLayout) findViewById(R.id.confirmpass);
        Mobilenumber = (TextInputLayout) findViewById(R.id.Mobilenumber);
        Location = (TextInputLayout) findViewById(R.id.Location);
        Area = (TextInputLayout) findViewById(R.id.Area);

        getlocation = (Button) findViewById(R.id.getlocation);
        already_registered = (Button) findViewById(R.id.already_registered);
        register = (Button) findViewById(R.id.register);

//        Location.setVisibility(View.INVISIBLE);
        DB = new MyDatabaseHelper(this);

//        DB = new DBHelper(this);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String fname = Fname.getEditText().getText().toString();
                String lname = Lname.getEditText().getText().toString();
                String emailid = Emailid.getEditText().getText().toString();
                String password = Password.getEditText().getText().toString();
                String confpassword = confirmpass.getEditText().getText().toString();
                String mobile = Mobilenumber.getEditText().getText().toString();
                String location = Location.getEditText().getText().toString();
                String area = Area.getEditText().getText().toString();

                if(fname.equals("") || lname.equals("") || emailid.equals("") || password.equals("") || confpassword.equals("") || mobile.equals("")  || area.equals("")) {
                    Toast.makeText(UserRegistration.this, "Please enter all the fields", Toast.LENGTH_LONG).show();
                }
                else
                    {
                    if(password.equals(confpassword)){
                        boolean status = DB.addUser(fname, lname, emailid, mobile,password, location, area);
                        if (status) {
                            Toast.makeText(getApplicationContext(), "Registration Successfully", Toast.LENGTH_LONG).show();
                            Intent i = new Intent(getApplicationContext(), HomeActivity.class);
                            startActivity(i);
                        } else {
                            Toast.makeText(getApplicationContext(), "You are not Registerd!", Toast.LENGTH_LONG).show();

                        }
//                        else{
//                            Toast.makeText(UserRegistration.this, "User already exists! please sign in", Toast.LENGTH_SHORT).show();
//                    }
                    }else{
                        Toast.makeText( UserRegistration.this, "Passwords not matching", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });

        already_registered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SignIn.class);
                startActivity(intent);
            }
        });



    }
}