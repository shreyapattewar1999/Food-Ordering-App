package com.example.foodon;

import androidx.appcompat.app.AppCompatActivity;
import com.example.foodon.R;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.database.Cursor;

import com.google.android.material.textfield.TextInputLayout;

public class SignIn extends AppCompatActivity {

    EditText Lemail;
    EditText Lpassword;
    Button Login_btn;
    TextView JumpToRegisteration;
    MyDatabaseHelper DB;
    Boolean checkuserpass;

    String login_email, login_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        Lemail = (EditText) findViewById(R.id.Lemail);
        Lpassword = (EditText) findViewById(R.id.Lpassword);

//        Lemail = (EditText)findViewById(R.id.Lemail);
//        Lpassword = (EditText)findViewById(R.id.Lpassword);

        Login_btn = (Button)findViewById(R.id.Login_btn);
        JumpToRegisteration =(TextView) findViewById(R.id.JumpToRegisteration);

        Login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login_email = Lemail.getText().toString();
                login_password = Lpassword.getText().toString();

                Toast.makeText(SignIn.this, login_email + login_password, Toast.LENGTH_SHORT).show();


                if(login_email.equals("") || login_password.equals("")){
                    Toast.makeText(SignIn.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();}
                else{

                    int status =Integer.parseInt( DB.getLoginData(login_email, login_password));
                    if (status>0) {
                        Toast.makeText(getApplicationContext(), "Login Successfully", Toast.LENGTH_LONG).show();
                        Intent i = new Intent(getApplicationContext(), HomeActivity.class);
                        startActivity(i);
                    } else {
                        Toast.makeText(getApplicationContext(), "You are not Registerd!", Toast.LENGTH_LONG).show();

                    }
                }}

        });

        JumpToRegisteration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login_email = Lemail.getText().toString();
                login_password = Lpassword.getText().toString();

                Toast.makeText(SignIn.this, login_email + login_password, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), UserRegistration.class);
                startActivity(intent);
            }
        });

    }
}